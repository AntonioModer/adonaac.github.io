local Game = fg.Object:extend('Game')

function Game:new()

end

function Game:update(dt)

end

function Game:draw()

end

return Game
