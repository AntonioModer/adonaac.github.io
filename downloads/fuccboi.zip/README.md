[**fuccboiGDX**](http://fuccboi.moe/) is a 2D game making code-centric engine/framework that provides additional higher level functionalities 
on top of [LÖVE](https://www.love2d.org/), making game creation easier, faster, and buzzword! It’s free, open source 
and supported on Windows, Linux and OSX.
