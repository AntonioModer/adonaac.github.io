# Love Frames

## Information

Love Frames is a GUI library for [L�VE](https://love2d.org/). For information on installation and usage, please visit the [wiki](http://nikolairesokav.com/documents/?page=loveframes/main). A demo of the library can be found at: http://nikolairesokav.com/projects/loveframes/

## License

Love Frames is licensed under the Creative Commons Attribution 3.0 Unported (CC BY 3.0) license.
For more information on this license, please read license.txt or visit this web page: http://creativecommons.org/licenses/by/3.0/

## Credits

Created by Kenny Shields

**Third-Party Libraries**

- middleclass by kikito - https://github.com/kikito/middleclass